package com.example.mhnhsplash

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class Screen2 : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen2)

        Handler().postDelayed({
            startActivity(Intent(this, Screen3::class.java))
            finish()
        }, 4000)
    }
}